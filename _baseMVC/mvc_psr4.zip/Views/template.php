<html>
<head>
	<title>Site</title>
</head>
<body>
	<h1>Site</h1>
	<?php $this->loadViewInTemplate($viewName, $viewData); ?>
</body>
</html>