<h3>Lista</h3>

<?php
foreach($lista as $item) {
	echo "NOME: ".$item['name']."<br/>";
}